package demo;
import java.util.*;

public class RPS {
    static private String initMsg = "Enter Number of rounds to play";
	//static private String errorMsg = "Not a valid input. Program shutting down";
	static private String inputMsg = "Enter your choice from : Rock, Paper, Scissors";



    public static void main(String[] args) {
        Scanner myScanner = new Scanner(System.in);

    }
}
