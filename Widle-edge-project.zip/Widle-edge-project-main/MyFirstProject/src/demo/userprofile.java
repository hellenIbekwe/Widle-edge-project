package demo;

public class userprofile {
    private String UserName;
    private String Password;
    private String email;
}
