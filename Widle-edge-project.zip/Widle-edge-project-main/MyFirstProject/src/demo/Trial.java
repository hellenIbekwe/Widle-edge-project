package demo;

public class Trial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sampleInput = "Hello World How Are You";
		
		//Sample Output
		// H : Hello How
		// W : World 
		// A : Are
		// Y : You
		
		
		display(formatTheInput(sampleInput));
	}

	private static String formatTheInput(String sampleInput) {
		// TODO Auto-generated method stub
		String StringToReturn = "";
        //Step1 : Split the String
        //
        //Step2 : Extract first Char of each word.
        //Step3 : Add the Extracted Char as "Key" and "Value" to a Map/Set/Tablle
		// Code to format the String
		
		return StringToReturn;
	}

	private static void display(String outputString) {
		// TODO Auto-generated method stub
		
	}

}