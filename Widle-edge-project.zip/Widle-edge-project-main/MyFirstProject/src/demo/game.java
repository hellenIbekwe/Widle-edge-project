package demo;

public class game {
    private String GameName;
    private int NumberOfPlayers;
    private int Age;
    private String Description;
    private String Rules;
    private byte[] DemoVideo;
    private int EstTime;
    private String Help;
    private int FitnessLevel;
    private String Dificulty;
}