package demo;

public class TickTack {
    private String Player1;
    private String 	Player2;
}
