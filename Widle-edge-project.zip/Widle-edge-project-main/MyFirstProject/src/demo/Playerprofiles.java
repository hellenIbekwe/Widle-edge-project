package demo;

public class Playerprofiles {
    private String ScreenName;
    private byte[] Image;
}
