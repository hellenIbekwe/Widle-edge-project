package demo;

public class player {
    private int Id;
    private String Name;
    private String PlayerProfile;
    private String 	UserProfile;
}
